## Tested & working with:
  VMware Workstation 10
  VMware Player 6
  VMware Fusion 6
  [*]Virtualbox 4.3.10
  [**]VMware Workstation 9

 [*] Need to type in the following command at 'mountroot>' prompt: ufs:/dev/ada0p2
[**] Need to use "Kioptrix2014_vmware8.vmx"


## Date
2014-April-007


## Homepage
http://www.kioptrix.com/blog/a-new-vm-after-almost-2-years/


## About the VM
As usual, this vulnerable machine is targeted at the beginner. It’s not meant for the seasoned pentester or security geek that’s been at this sort of stuff for 10 years. Everyone needs a place to start and all I want to do is help in that regard.

Also, before powering on the VM I suggest you remove the network card and re-add it. For some oddball reason it doesn’t get its IP (well I do kinda know why but don’t want to give any details away). So just add the VM to your virtualization software, remove and then add a network card. Set it to bridge mode and you should be good to go.

This was created using ESX 5.0 and tested on Fusion, but shouldn’t be much of a problem on other platforms.
